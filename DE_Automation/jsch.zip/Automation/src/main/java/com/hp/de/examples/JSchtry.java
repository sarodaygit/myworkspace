package com.hp.de.examples;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

public class JSchtry {
	/*
	 * ==========================================================================
	 * ============================= Method to read Property file
	 */
	public  String ReadProperty(String key) throws FileNotFoundException,IOException 
	{
		Properties prop = new Properties();
		prop.load(new FileInputStream("C:\\nagaraj\\workspace\\java\\Automation\\ssh.properties"));
		String value = prop.getProperty(key);
		return value;
	}
	

	public Session sessionconnect(String host1) throws FileNotFoundException,
	IOException, JSchException 
	{
		Session session = null;
		String host = host1;
		Properties p = new Properties();
		p.put("StrictHostKeyChecking", "no");
		System.out.println("ppk file =  "+ new JSchtry().ReadProperty("ppkfile"));
		System.out.println("ppkuser = " + new JSchtry().ReadProperty("ppkuser"));
		JSch jsch = new JSch();
		File file = new File(new JSchtry().ReadProperty("ppkfile"));
		final byte[] prvkey = FileUtils.readFileToByteArray(file);
		
		
		final byte[] emptyPassPhrase = new byte[0];
		jsch.addIdentity(host, prvkey, null, emptyPassPhrase);
		
		jsch.addIdentity(new JSchtry().ReadProperty("ppkfile"));
		String ppkuser=new JSchtry().ReadProperty("ppkuser");
		
		session = jsch.getSession(ppkuser, host, 22);
		session.setConfig(p);
		session.connect();
		return session;
	}

	
	public ResultSet DBExecuteSHARD(String sql, String host)
			throws SQLException, InstantiationException,
			IllegalAccessException, ClassNotFoundException, JSchException,
			FileNotFoundException, IOException 
			{
		String driverName = "com.mysql.jdbc.Driver";
		String dbuserName = "root";
		String dbpassword = "opelin";
		int lport = 5656;
		String url = "jdbc:mysql://localhost:" + lport + "/cpgDB_SHARD";
		Statement stmt = null;
		String rhost = host;
		int rport = 3306;
		Connection conn = null;
		Session session = new JSchtry().sessionconnect(host);
		session.setPortForwardingL(lport, rhost, rport);
		Class.forName(driverName).newInstance();
		conn = (Connection) DriverManager.getConnection(url, dbuserName,dbpassword);
		stmt = (Statement) conn.createStatement();
		ResultSet rs = stmt.executeQuery(sql);
		session.disconnect();
		return rs;
			}

	
	

	public static void main(String args[]) throws FileNotFoundException,
	IOException, InterruptedException, JSchException,
	InstantiationException, IllegalAccessException,
	ClassNotFoundException, SQLException, InvalidFormatException 
	{
//		String app_sql="select PrinterID from Printer where PrinterEmailAddress = 'apciv73awt356@dev02.hp-webplatform.com'";
		String app_sql="select PrinterID from Printer where PrinterEmailAddress = '24ids66osjed@dev02.hp-webplatform.com'";
		ResultSet app_rs=new JSchtry().DBExecuteSHARD(app_sql, "dev02cpg01.hp-webplatform.com");
		
		
		while (app_rs.next()) 
		{
			String pid = app_rs.getString(1);

			System.out.println(pid);
			
		}
		

	}
}	
